CREATE TABLE Inventory
(
   ProductID int,
   ProductName varchar(1000),
   Quantity int
);

INSERT INTO Inventory(ProductID,ProductName,Quantity) VALUES
(1,'Mobile',100),
(2,'Laptop',200),
(3,'Headphones',300);
